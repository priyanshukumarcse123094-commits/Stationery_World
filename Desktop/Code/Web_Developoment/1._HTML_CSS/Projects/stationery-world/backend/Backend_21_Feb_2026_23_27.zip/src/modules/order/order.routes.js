const express = require('express');
const router = express.Router();
const {
  createOrder,
  confirmOrder,
  getUserOrders,
  getOrderById,
  cancelOrder,
  getAllOrders,
  updateOrderStatus,
  requestReturn,
  markOrderAsPaid,      // ✅ NEW
  processRefund         // ✅ NEW
} = require('./order.controller');
const { authMiddleware, adminMiddleware } = require('../user/user.middleware');

// Customer routes (authenticated)
router.post('/', authMiddleware, createOrder);
router.post('/:id/confirm', authMiddleware, confirmOrder);
router.get('/', authMiddleware, getUserOrders);
router.get('/:id', authMiddleware, getOrderById);
router.put('/:id/cancel', authMiddleware, cancelOrder);
router.put('/:id/return', authMiddleware, requestReturn);

// Admin routes
router.get('/admin/all', authMiddleware, adminMiddleware, getAllOrders);
router.put('/admin/:id/status', authMiddleware, adminMiddleware, updateOrderStatus);
router.post('/admin/:id/mark-paid', authMiddleware, adminMiddleware, markOrderAsPaid);      // ✅ NEW
router.post('/admin/:id/refund', authMiddleware, adminMiddleware, processRefund);           // ✅ NEW

module.exports = router;