const express = require('express');
const router = express.Router();
const {
  getBargainConfig,
  getBargainAttempts,
  makeBargainAttempt,
  setBargainConfig
} = require('./bargain.controller');
const { authMiddleware, adminMiddleware } = require('../user/user.middleware');

// Customer routes
router.get('/config/:productId', getBargainConfig);
router.get('/attempts/:productId', authMiddleware, getBargainAttempts);
router.post('/attempt', authMiddleware, makeBargainAttempt);

// Admin routes
router.post('/config/:productId', authMiddleware, adminMiddleware, setBargainConfig);

module.exports = router;
