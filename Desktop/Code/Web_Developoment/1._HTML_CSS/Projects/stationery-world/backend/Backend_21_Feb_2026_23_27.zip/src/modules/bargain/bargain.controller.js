const prisma = require('../../../prisma/client');

// Get bargain configuration for a product
const getBargainConfig = async (req, res) => {
  try {
    const { productId } = req.params;

    console.log('Get bargain config for product:', productId);

    const product = await prisma.product.findUnique({
      where: { id: parseInt(productId) },
      include: {
        bargainConfig: true
      }
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    if (!product.bargainable) {
      return res.status(400).json({
        success: false,
        message: 'This product is not bargainable.'
      });
    }

    if (!product.bargainConfig) {
      return res.status(404).json({
        success: false,
        message: 'Bargain configuration not found for this product.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Bargain configuration retrieved successfully.',
      data: product.bargainConfig
    });
  } catch (error) {
    console.error('Get bargain config error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching bargain configuration.'
    });
  }
};

// Get user's bargain attempts for a product
const getBargainAttempts = async (req, res) => {
  try {
    const userId = req.user.id;
    const { productId } = req.params;

    console.log('Get bargain attempts:', { userId, productId });

    const attempts = await prisma.bargainAttempt.findMany({
      where: {
        userId,
        productId: parseInt(productId),
        orderId: null // Only show active attempts (not yet associated with an order)
      },
      orderBy: {
        createdAt: 'asc'
      }
    });

    return res.status(200).json({
      success: true,
      message: 'Bargain attempts retrieved successfully.',
      data: attempts,
      count: attempts.length,
      remainingAttempts: Math.max(0, 3 - attempts.length)
    });
  } catch (error) {
    console.error('Get bargain attempts error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching bargain attempts.'
    });
  }
};

// Make a bargain attempt
const makeBargainAttempt = async (req, res) => {
  try {
    const userId = req.user.id;
    const { productId, offeredPrice } = req.body;

    console.log('Make bargain attempt:', { userId, productId, offeredPrice });

    if (!productId || !offeredPrice) {
      return res.status(400).json({
        success: false,
        message: 'Product ID and offered price are required.'
      });
    }

    // Get product with bargain config
    const product = await prisma.product.findUnique({
      where: { id: parseInt(productId) },
      include: {
        bargainConfig: true
      }
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    if (!product.bargainable || !product.bargainConfig || !product.bargainConfig.isActive) {
      return res.status(400).json({
        success: false,
        message: 'This product is not available for bargaining.'
      });
    }

    // Check existing attempts for this product (not yet associated with an order)
    const existingAttempts = await prisma.bargainAttempt.findMany({
      where: {
        userId,
        productId: parseInt(productId),
        orderId: null
      }
    });

    if (existingAttempts.length >= product.bargainConfig.maxAttempts) {
      return res.status(400).json({
        success: false,
        message: `Maximum ${product.bargainConfig.maxAttempts} attempts reached for this product.`
      });
    }

    const attemptNumber = existingAttempts.length + 1;

    // Determine if offered price matches any tier
    const config = product.bargainConfig;
    let accepted = false;
    let matchedTier = null;

    if (parseFloat(offeredPrice) >= config.tier1Price) {
      accepted = true;
      matchedTier = 1;
    } else if (parseFloat(offeredPrice) >= config.tier2Price) {
      accepted = true;
      matchedTier = 2;
    } else if (parseFloat(offeredPrice) >= config.tier3Price) {
      accepted = true;
      matchedTier = 3;
    }

    // Create bargain attempt
    const attempt = await prisma.bargainAttempt.create({
      data: {
        userId,
        productId: parseInt(productId),
        attemptNumber,
        offeredPrice: parseFloat(offeredPrice),
        accepted
      }
    });

    console.log('Bargain attempt created:', attempt.id);

    // If accepted, add to cart with bargain price
    if (accepted) {
      await prisma.cart.upsert({
        where: {
          userId_productId: {
            userId,
            productId: parseInt(productId)
          }
        },
        update: {
          priceAtAdd: parseFloat(offeredPrice),
          bargainApplied: true,
          quantity: 1
        },
        create: {
          userId,
          productId: parseInt(productId),
          quantity: 1,
          priceAtAdd: parseFloat(offeredPrice),
          bargainApplied: true
        }
      });
    }

    const remainingAttempts = product.bargainConfig.maxAttempts - attemptNumber;

    return res.status(201).json({
      success: true,
      message: accepted 
        ? `Bargain accepted! Matched tier ${matchedTier}. Item added to cart at ₹${offeredPrice}` 
        : `Bargain rejected. ${remainingAttempts} attempt(s) remaining.`,
      data: {
        attempt,
        accepted,
        matchedTier,
        remainingAttempts,
        nextTierPrice: attemptNumber === 1 ? config.tier1Price : attemptNumber === 2 ? config.tier2Price : config.tier3Price
      }
    });
  } catch (error) {
    console.error('Make bargain attempt error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while making bargain attempt.'
    });
  }
};

// Set bargain configuration for a product (Admin only)
const setBargainConfig = async (req, res) => {
  try {
    const { productId } = req.params;
    const { tier1Price, tier2Price, tier3Price, maxAttempts = 3, isActive = true } = req.body;

    console.log('Set bargain config for product:', productId);

    if (!tier1Price || !tier2Price || !tier3Price) {
      return res.status(400).json({
        success: false,
        message: 'All three tier prices are required.'
      });
    }

    // Validate tier pricing (tier1 > tier2 > tier3)
    if (parseFloat(tier1Price) <= parseFloat(tier2Price) || parseFloat(tier2Price) <= parseFloat(tier3Price)) {
      return res.status(400).json({
        success: false,
        message: 'Tier prices must be: tier1 > tier2 > tier3'
      });
    }

    // Check if product exists
    const product = await prisma.product.findUnique({
      where: { id: parseInt(productId) }
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    // Upsert bargain configuration
    const config = await prisma.bargainConfig.upsert({
      where: { productId: parseInt(productId) },
      update: {
        tier1Price: parseFloat(tier1Price),
        tier2Price: parseFloat(tier2Price),
        tier3Price: parseFloat(tier3Price),
        maxAttempts: parseInt(maxAttempts),
        isActive
      },
      create: {
        productId: parseInt(productId),
        tier1Price: parseFloat(tier1Price),
        tier2Price: parseFloat(tier2Price),
        tier3Price: parseFloat(tier3Price),
        maxAttempts: parseInt(maxAttempts),
        isActive
      }
    });

    // Also update product's bargainable flag
    await prisma.product.update({
      where: { id: parseInt(productId) },
      data: { bargainable: isActive }
    });

    console.log('Bargain config set:', config.id);

    return res.status(200).json({
      success: true,
      message: 'Bargain configuration updated successfully.',
      data: config
    });
  } catch (error) {
    console.error('Set bargain config error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while setting bargain configuration.'
    });
  }
};

module.exports = {
  getBargainConfig,
  getBargainAttempts,
  makeBargainAttempt,
  setBargainConfig
};
