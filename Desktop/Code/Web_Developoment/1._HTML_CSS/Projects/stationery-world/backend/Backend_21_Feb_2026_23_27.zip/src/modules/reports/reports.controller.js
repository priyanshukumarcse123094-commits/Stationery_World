const prisma = require('../../../prisma/client');

// ─────────────────────────────────────────────────────────────────
// HELPER: "this admin's orders" filter
// An order belongs to an admin when:
//   1. adminId = req.user.id  (admin confirmed / managed it), OR
//   2. userId  = req.user.id  AND type is SELF or ADMIN
// ─────────────────────────────────────────────────────────────────
const adminOrdersWhere = (adminId, extraWhere = {}) => ({
  ...extraWhere,
  OR: [
    { adminId },
    { userId: adminId, type: { in: ['SELF', 'ADMIN'] } }
  ]
});

// ─────────────────────────────────────────────────────────────────
// SALES REPORT — this admin's PAID orders only
// ─────────────────────────────────────────────────────────────────
const getSalesReport = async (req, res) => {
  try {
    const adminId = req.user.id;
    const { startDate, endDate, groupBy = 'day' } = req.query;

    console.log('Get sales report request');

    // ✅ ONLY PAID ORDERS
    const statusFilter = { 
      status: { in: ['PAID', 'SHIPPED', 'DELIVERED'] },
      isPaid: true  // ✅ CRITICAL: Only count paid orders
    };

    if (startDate || endDate) {
      statusFilter.createdAt = {};
      if (startDate) statusFilter.createdAt.gte = new Date(startDate);
      if (endDate)   statusFilter.createdAt.lte = new Date(endDate);
    }

    const orders = await prisma.order.findMany({
      where: adminOrdersWhere(adminId, statusFilter),
      include: {
        items: { include: { product: true } },
        payment: true
      },
      orderBy: { createdAt: 'asc' }
    });

    // Calculate metrics
    const totalOrders = orders.length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;

    // Calculate total profit
    let totalProfit = 0;
    orders.forEach(order => {
      order.items.forEach(item => {
        if (item.product) {
          const profit = (item.priceAtOrder - item.product.costPrice) * item.quantity;
          totalProfit += profit;
        }
      });
    });

    // Group by date
    const salesByDate = {};
    orders.forEach(order => {
      const date = new Date(order.createdAt).toISOString().split('T')[0];
      if (!salesByDate[date]) {
        salesByDate[date] = { date, orders: 0, revenue: 0, profit: 0 };
      }
      salesByDate[date].orders  += 1;
      salesByDate[date].revenue += order.totalAmount;

      order.items.forEach(item => {
        if (item.product) {
          const profit = (item.priceAtOrder - item.product.costPrice) * item.quantity;
          salesByDate[date].profit += profit;
        }
      });
    });

    const salesData = Object.values(salesByDate);

    console.log('Sales report generated:', { totalOrders, totalRevenue, totalProfit });

    return res.status(200).json({
      success: true,
      message: 'Sales report generated successfully.',
      data: {
        summary: {
          totalOrders,
          totalRevenue,
          totalProfit,
          averageOrderValue,
          profitMargin: totalRevenue > 0
            ? ((totalProfit / totalRevenue) * 100).toFixed(2) + '%'
            : '0%'
        },
        salesByDate: salesData,
        orders
      }
    });
  } catch (error) {
    console.error('Get sales report error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while generating sales report.'
    });
  }
};

// ─────────────────────────────────────────────────────────────────
// REVENUE REPORT — this admin's PAID revenue by category
// ─────────────────────────────────────────────────────────────────
const getRevenueReport = async (req, res) => {
  try {
    const adminId = req.user.id;
    const { startDate, endDate, period } = req.query;

    console.log('Get revenue report request');

    // ✅ ONLY PAID ORDERS
    const statusFilter = { 
      status: { in: ['PAID', 'SHIPPED', 'DELIVERED'] },
      isPaid: true  // ✅ CRITICAL: Only count paid orders
    };

    if (startDate || endDate) {
      statusFilter.createdAt = {};
      if (startDate) statusFilter.createdAt.gte = new Date(startDate);
      if (endDate)   statusFilter.createdAt.lte = new Date(endDate);
    } else if (period === 'monthly') {
      // Current month — used by Dashboard bar chart
      const now   = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end   = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59);
      statusFilter.createdAt = { gte: start, lte: end };
    }

    const orders = await prisma.order.findMany({
      where: adminOrdersWhere(adminId, statusFilter),
      include: {
        items: { include: { product: true } },
        payment: true
      }
    });

    // Revenue by category
    const revenueByCategory = {
      STATIONERY: { revenue: 0, orders: 0, profit: 0 },
      BOOKS:      { revenue: 0, orders: 0, profit: 0 },
      TOYS:       { revenue: 0, orders: 0, profit: 0 }
    };

    orders.forEach(order => {
      order.items.forEach(item => {
        if (!item.product) return;
        const category    = item.product.category;
        const itemRevenue = item.priceAtOrder * item.quantity;
        const itemProfit  = (item.priceAtOrder - item.product.costPrice) * item.quantity;

        if (revenueByCategory[category]) {
          revenueByCategory[category].revenue += itemRevenue;
          revenueByCategory[category].profit  += itemProfit;
        }
      });

      // Count order for primary category (first item's category)
      if (order.items.length > 0 && order.items[0].product) {
        const category = order.items[0].product.category;
        if (revenueByCategory[category]) {
          revenueByCategory[category].orders += 1;
        }
      }
    });

    // Payment method breakdown — scoped to this admin's PAID orders
    const paymentMethods = await prisma.payment.findMany({
      where: {
        status: 'SUCCESS',
        order: adminOrdersWhere(adminId, {
          status: { in: ['PAID', 'SHIPPED', 'DELIVERED'] },
          isPaid: true  // ✅ ONLY PAID ORDERS
        })
      }
    });

    const paymentMethodBreakdown = {};
    paymentMethods.forEach(payment => {
      if (!paymentMethodBreakdown[payment.method]) {
        paymentMethodBreakdown[payment.method] = { count: 0, amount: 0 };
      }
      paymentMethodBreakdown[payment.method].count  += 1;
      paymentMethodBreakdown[payment.method].amount += payment.amount;
    });

    const totalRevenue = orders.reduce((sum, order) => sum + order.totalAmount, 0);

    // Group by day for monthly chart (Dashboard)
    const revenueByDay = {};
    orders.forEach(order => {
      const day = new Date(order.createdAt).getDate().toString();
      if (!revenueByDay[day]) {
        revenueByDay[day] = { day, totalRevenue: 0, orderCount: 0 };
      }
      revenueByDay[day].totalRevenue += order.totalAmount;
      revenueByDay[day].orderCount   += 1;
    });

    console.log('Revenue report generated');

    // period=monthly → day-grouped array for Dashboard bar chart
    if (period === 'monthly') {
      return res.status(200).json({
        success: true,
        message: 'Revenue report generated successfully.',
        data: Object.values(revenueByDay).sort((a, b) => parseInt(a.day) - parseInt(b.day))
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Revenue report generated successfully.',
      data: {
        totalRevenue,
        revenueByCategory,
        paymentMethodBreakdown
      }
    });
  } catch (error) {
    console.error('Get revenue report error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while generating revenue report.'
    });
  }
};

// ─────────────────────────────────────────────────────────────────
// INVENTORY REPORT — global (products are shared across all admins)
// ─────────────────────────────────────────────────────────────────
const getInventoryReport = async (req, res) => {
  try {
    console.log('Get inventory report request');

    const products = await prisma.product.findMany({
      where: { isActive: true },
      include: {
        images: { where: { isPrimary: true }, take: 1 }
      }
    });

    const totalProducts      = products.length;
    const lowStockProducts   = products.filter(p => p.totalStock <= p.lowStockThreshold);
    const lowStockCount      = lowStockProducts.length;
    const outOfStockProducts = products.filter(p => p.totalStock === 0);
    const outOfStockCount    = outOfStockProducts.length;

    const byCategory = {
      STATIONERY: { total: 0, lowStock: 0, outOfStock: 0, totalValue: 0 },
      BOOKS:      { total: 0, lowStock: 0, outOfStock: 0, totalValue: 0 },
      TOYS:       { total: 0, lowStock: 0, outOfStock: 0, totalValue: 0 }
    };

    products.forEach(product => {
      const category = product.category;
      if (byCategory[category]) {
        byCategory[category].total      += 1;
        byCategory[category].totalValue += product.totalStock * product.costPrice;
        if (product.totalStock <= product.lowStockThreshold) byCategory[category].lowStock   += 1;
        if (product.totalStock === 0)                        byCategory[category].outOfStock += 1;
      }
    });

    const totalInventoryValue = products.reduce((sum, product) => {
      return sum + (product.totalStock * product.costPrice);
    }, 0);

    console.log('Inventory report generated');

    return res.status(200).json({
      success: true,
      message: 'Inventory report generated successfully.',
      data: {
        summary: {
          totalProducts,
          lowStockCount,
          outOfStockCount,
          totalInventoryValue
        },
        byCategory,
        lowStockProducts: lowStockProducts.map(p => ({
          productId: p.id,
          product: p,
          quantity: p.totalStock,
          isLowStock: true,
          lowStockThreshold: p.lowStockThreshold
        })),
        outOfStockProducts: outOfStockProducts.map(p => ({
          productId: p.id,
          product: p,
          quantity: 0,
          isLowStock: true,
          lowStockThreshold: p.lowStockThreshold
        }))
      }
    });
  } catch (error) {
    console.error('Get inventory report error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while generating inventory report.'
    });
  }
};

// ─────────────────────────────────────────────────────────────────
// TOP PRODUCTS — from this admin's PAID orders
// ─────────────────────────────────────────────────────────────────
const getTopProducts = async (req, res) => {
  try {
    const adminId = req.user.id;
    const { limit = 10, sortBy = 'revenue' } = req.query;

    console.log('Get top products request');

    const orderItems = await prisma.orderItem.findMany({
      where: {
        order: adminOrdersWhere(adminId, {
          status: { in: ['PAID', 'SHIPPED', 'DELIVERED'] },
          isPaid: true  // ✅ ONLY PAID ORDERS
        })
      },
      include: { product: true }
    });

    const productStats = {};

    orderItems.forEach(item => {
      if (!item.product) return;
      const productId = item.productId;
      if (!productStats[productId]) {
        productStats[productId] = {
          product:       item.product,
          totalQuantity: 0,
          totalRevenue:  0,
          totalProfit:   0,
          orderCount:    0
        };
      }
      productStats[productId].totalQuantity += item.quantity;
      productStats[productId].totalRevenue  += item.priceAtOrder * item.quantity;
      productStats[productId].totalProfit   += (item.priceAtOrder - item.product.costPrice) * item.quantity;
      productStats[productId].orderCount    += 1;
    });

    let topProducts = Object.values(productStats);

    if (sortBy === 'revenue')  topProducts.sort((a, b) => b.totalRevenue  - a.totalRevenue);
    if (sortBy === 'quantity') topProducts.sort((a, b) => b.totalQuantity - a.totalQuantity);
    if (sortBy === 'profit')   topProducts.sort((a, b) => b.totalProfit   - a.totalProfit);

    topProducts = topProducts.slice(0, parseInt(limit));

    console.log('Top products report generated');

    return res.status(200).json({
      success: true,
      message: 'Top products retrieved successfully.',
      data: topProducts
    });
  } catch (error) {
    console.error('Get top products error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching top products.'
    });
  }
};

// ─────────────────────────────────────────────────────────────────
// CATEGORY PERFORMANCE — from this admin's PAID orders
// ─────────────────────────────────────────────────────────────────
const getCategoryPerformance = async (req, res) => {
  try {
    const adminId = req.user.id;

    console.log('Get category performance request');

    const orderItems = await prisma.orderItem.findMany({
      where: {
        order: adminOrdersWhere(adminId, {
          status: { in: ['PAID', 'SHIPPED', 'DELIVERED'] },
          isPaid: true  // ✅ ONLY PAID ORDERS
        })
      },
      include: { product: true }
    });

    const categoryStats = {
      STATIONERY: { revenue: 0, profit: 0, quantity: 0, orders: 0 },
      BOOKS:      { revenue: 0, profit: 0, quantity: 0, orders: 0 },
      TOYS:       { revenue: 0, profit: 0, quantity: 0, orders: 0 }
    };

    const categoryOrders = new Set();

    orderItems.forEach(item => {
      if (!item.product) return;
      const category = item.product.category;
      if (categoryStats[category]) {
        categoryStats[category].revenue  += item.priceAtOrder * item.quantity;
        categoryStats[category].profit   += (item.priceAtOrder - item.product.costPrice) * item.quantity;
        categoryStats[category].quantity += item.quantity;
        categoryOrders.add(`${category}-${item.orderId}`);
      }
    });

    // Count unique orders per category
    Object.keys(categoryStats).forEach(category => {
      const ordersForCategory = Array.from(categoryOrders).filter(key => key.startsWith(category));
      categoryStats[category].orders = ordersForCategory.length;
    });

    // Calculate profit margins
    Object.keys(categoryStats).forEach(category => {
      const stats = categoryStats[category];
      stats.profitMargin = stats.revenue > 0
        ? ((stats.profit / stats.revenue) * 100).toFixed(2) + '%'
        : '0%';
      stats.averageOrderValue = stats.orders > 0
        ? (stats.revenue / stats.orders).toFixed(2)
        : 0;
    });

    console.log('Category performance report generated');

    return res.status(200).json({
      success: true,
      message: 'Category performance retrieved successfully.',
      data: Object.entries(categoryStats).map(([category, stats]) => ({
        category,
        totalRevenue: stats.revenue,
        orderCount: stats.orders,
        ...stats
      }))
    });
  } catch (error) {
    console.error('Get category performance error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching category performance.'
    });
  }
};

// ─────────────────────────────────────────────────────────────────
// DASHBOARD SUMMARY
//   totalCustomers    → ALL customers (global)
//   totalProducts     → ALL active products (global)
//   lowStockProducts  → global low-stock count
//   totalOrders       → this admin's PAID orders
//   pendingOrders     → this admin's pending orders
//   totalRevenue      → this admin's revenue (PAID orders only)
//   totalProfit       → this admin's profit (PAID orders only)
//   averageOrderValue → this admin's average order value (PAID orders only)
// ─────────────────────────────────────────────────────────────────
const getDashboardSummary = async (req, res) => {
  try {
    const adminId = req.user.id;

    console.log('Get dashboard summary request');

    // ── Global stats ──────────────────────────────────────────────
    const totalCustomers = await prisma.user.count({
      where: { role: 'CUSTOMER', isActive: true }
    });

    const totalProducts = await prisma.product.count({
      where: { isActive: true }
    });

    const allProducts = await prisma.product.findMany({
      where: { isActive: true },
      select: { totalStock: true, lowStockThreshold: true }
    });

    const lowStockProducts = allProducts.filter(
      p => p.totalStock <= p.lowStockThreshold
    ).length;

    // ── This admin's orders ───────────────────────────────────────
    // ✅ Total PAID orders only
    const totalOrders = await prisma.order.count({
      where: adminOrdersWhere(adminId, { isPaid: true })
    });

    const pendingOrders = await prisma.order.count({
      where: adminOrdersWhere(adminId, { status: 'PENDING' })
    });

    // ✅ Revenue + profit from this admin's PAID orders
    const paidOrders = await prisma.order.findMany({
      where: adminOrdersWhere(adminId, {
        status: { in: ['PAID', 'SHIPPED', 'DELIVERED'] },
        isPaid: true  // ✅ CRITICAL: Only paid orders
      }),
      include: {
        items: {
          include: { product: { select: { costPrice: true } } }
        }
      }
    });

    const totalRevenue      = paidOrders.reduce((sum, o) => sum + o.totalAmount, 0);
    const averageOrderValue = paidOrders.length > 0 ? totalRevenue / paidOrders.length : 0;

    let totalProfit = 0;
    paidOrders.forEach(order => {
      order.items.forEach(item => {
        if (item.product) {
          totalProfit += (item.priceAtOrder - item.product.costPrice) * item.quantity;
        }
      });
    });

    console.log('Dashboard summary generated');

    // Flat shape — matches exactly what Dashboard.jsx expects
    return res.status(200).json({
      success: true,
      message: 'Dashboard summary retrieved successfully.',
      data: {
        totalOrders,
        totalRevenue,
        totalProducts,
        totalCustomers,
        pendingOrders,
        lowStockProducts,
        averageOrderValue,
        totalProfit
      }
    });
  } catch (error) {
    console.error('Get dashboard summary error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching dashboard summary.'
    });
  }
};

const getProductDemand = async (req, res) => {
  try {
    console.log('Get product demand request');

    // Get all notification requests grouped by product
    const notifications = await prisma.productNotification.groupBy({
      by: ['productId'],
      _count: {
        userId: true
      },
      orderBy: {
        _count: {
          userId: 'desc'
        }
      },
      take: 10
    });

    // Fetch product details for each
    const demandData = await Promise.all(
      notifications.map(async (item) => {
        const product = await prisma.product.findUnique({
          where: { id: item.productId },
          include: { images: { where: { isPrimary: true }, take: 1 } }
        });

        return {
          productId: item.productId,
          product: product,
          requestCount: item._count.userId,
          isInStock: product ? product.totalStock > 0 : false
        };
      })
    );

    console.log('Product demand data generated');

    return res.status(200).json({
      success: true,
      message: 'Product demand data retrieved successfully.',
      data: demandData
    });
  } catch (error) {
    console.error('Get product demand error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching product demand.'
    });
  }
};

module.exports = {
  getSalesReport,
  getRevenueReport,
  getInventoryReport,
  getTopProducts,
  getCategoryPerformance,
  getDashboardSummary,
  getProductDemand
};