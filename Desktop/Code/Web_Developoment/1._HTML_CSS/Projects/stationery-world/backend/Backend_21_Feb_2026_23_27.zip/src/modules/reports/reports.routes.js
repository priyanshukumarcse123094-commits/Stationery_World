const express = require('express');
const router = express.Router();
const {
  getSalesReport,
  getRevenueReport,
  getInventoryReport,
  getTopProducts,
  getCategoryPerformance,
  getDashboardSummary,
  getProductDemand  // ← ADD THIS
} = require('./reports.controller');
const { authMiddleware, adminMiddleware } = require('../user/user.middleware');

// All reports routes require admin authentication
router.get('/sales', authMiddleware, adminMiddleware, getSalesReport);
router.get('/revenue', authMiddleware, adminMiddleware, getRevenueReport);
router.get('/inventory', authMiddleware, adminMiddleware, getInventoryReport);
router.get('/top-products', authMiddleware, adminMiddleware, getTopProducts);
router.get('/category-performance', authMiddleware, adminMiddleware, getCategoryPerformance);
router.get('/dashboard', authMiddleware, adminMiddleware, getDashboardSummary);
router.get('/demand', authMiddleware, adminMiddleware, getProductDemand);  // ← ADD THIS

module.exports = router;