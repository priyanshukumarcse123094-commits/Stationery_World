const prisma = require('../../../prisma/client');

// Get all inventory (Admin only)
const getAllInventory = async (req, res) => {
  try {
    const { isLowStock, category } = req.query;

    console.log('Get all inventory request');

    const where = { isActive: true };
    
    // Filter by low stock
    if (isLowStock === 'true') {
      where.totalStock = {
        lte: prisma.raw('\"lowStockThreshold\"')
      };
    }

    // Filter by category
    if (category) {
      where.category = category.toUpperCase();
    }

    const products = await prisma.product.findMany({
      where,
      include: {
        images: {
          where: { isPrimary: true },
          take: 1
        }
      },
      orderBy: {
        totalStock: 'asc'
      }
    });

    // Add low stock flag to each product
    const inventory = products.map(product => ({
      productId: product.id,
      product: product,
      quantity: product.totalStock,
      isLowStock: product.totalStock <= product.lowStockThreshold,
      lowStockThreshold: product.lowStockThreshold,
      lastUpdated: product.updatedAt
    }));

    console.log(`Found ${inventory.length} inventory records`);

    return res.status(200).json({
      success: true,
      message: 'Inventory retrieved successfully.',
      data: inventory,
      count: inventory.length
    });
  } catch (error) {
    console.error('Get all inventory error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching inventory.'
    });
  }
};

// Get low stock products (Admin only)
const getLowStockProducts = async (req, res) => {
  try {
    console.log('Get low stock products request');

    // Find products where totalStock <= lowStockThreshold
    const products = await prisma.product.findMany({
      where: {
        isActive: true
      },
      include: {
        images: {
          where: { isPrimary: true },
          take: 1
        }
      },
      orderBy: {
        totalStock: 'asc'
      }
    });

    // Filter to only low stock products
    const lowStockProducts = products.filter(
      product => product.totalStock <= product.lowStockThreshold
    );

    // Format response
    const lowStockInventory = lowStockProducts.map(product => ({
      productId: product.id,
      product: product,
      quantity: product.totalStock,
      isLowStock: true,
      lowStockThreshold: product.lowStockThreshold,
      lastUpdated: product.updatedAt
    }));

    console.log(`Found ${lowStockInventory.length} low stock products`);

    return res.status(200).json({
      success: true,
      message: 'Low stock products retrieved successfully.',
      data: lowStockInventory,
      count: lowStockInventory.length
    });
  } catch (error) {
    console.error('Get low stock products error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching low stock products.'
    });
  }
};

// Update inventory for a product (Admin only) - RESTOCK
const updateInventory = async (req, res) => {
  try {
    const { productId } = req.params;
    const { 
      quantityAdded,  // ✅ Changed from 'quantity' to 'quantityAdded'
      quantity,       // ✅ Keep backward compatibility
      costPrice, 
      baseSellingPrice, 
      bargainable, 
      images, 
      note,
      action = 'add'  // Default to 'add' for restock
    } = req.body;
    const adminId = req.user?.id;

    console.log('Update inventory request:', { productId, quantityAdded, quantity, action });

    // ✅ Accept either quantityAdded or quantity
    const qtyToAdd = quantityAdded !== undefined ? quantityAdded : quantity;

    if (qtyToAdd === undefined || qtyToAdd === null) {
      return res.status(400).json({
        success: false,
        message: 'Quantity is required.'
      });
    }

    const quantityNum = parseInt(qtyToAdd);
    if (isNaN(quantityNum)) {
      return res.status(400).json({
        success: false,
        message: 'Quantity must be a valid number.'
      });
    }

    // For restock, quantity must be positive
    if (action === 'add' && quantityNum <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity to add must be positive.'
      });
    }

    // Get product
    const product = await prisma.product.findUnique({
      where: { id: parseInt(productId) }
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    let newQuantity;
    let inventoryAction;

    if (action === 'set') {
      newQuantity = quantityNum;
      inventoryAction = 'ADJUST';
    } else if (action === 'add') {
      newQuantity = product.totalStock + quantityNum;
      inventoryAction = 'RESTOCK';
    } else if (action === 'remove') {
      newQuantity = product.totalStock - quantityNum;
      if (newQuantity < 0) {
        return res.status(400).json({
          success: false,
          message: 'Cannot remove more quantity than available.'
        });
      }
      inventoryAction = 'SALE';
    } else {
      return res.status(400).json({
        success: false,
        message: 'Invalid action. Must be: set, add, or remove'
      });
    }

    // Check if will be low stock
    const wasLowStock = product.totalStock <= product.lowStockThreshold;
    const isLowStock = newQuantity <= product.lowStockThreshold;

    // Build update data for product
    const updateData = {
      totalStock: newQuantity
    };

    // Update prices if provided
    if (costPrice !== undefined && costPrice !== null && costPrice !== '') {
      updateData.costPrice = parseFloat(costPrice);
    }
    if (baseSellingPrice !== undefined && baseSellingPrice !== null && baseSellingPrice !== '') {
      updateData.baseSellingPrice = parseFloat(baseSellingPrice);
    }
    if (bargainable !== undefined) {
      updateData.bargainable = bargainable;
    }

    // Update product stock and create inventory log in transaction
    const result = await prisma.$transaction(async (tx) => {
      // Update product stock and prices
      const updatedProduct = await tx.product.update({
        where: { id: parseInt(productId) },
        data: updateData,
        include: {
          images: true
        }
      });

      // Create inventory log
      await tx.inventoryLog.create({
        data: {
          productId: parseInt(productId),
          action: inventoryAction,
          quantity: action === 'remove' ? -quantityNum : quantityNum,
          adminId: adminId || null,
          note: note || `Inventory ${action}: ${quantityNum} units`
        }
      });

      // Add new images if provided
      if (Array.isArray(images) && images.length > 0) {
        const imgCreates = images.map(imgUrl => 
          tx.productImage.create({
            data: {
              productId: parseInt(productId),
              url: imgUrl,
              isPrimary: false
            }
          })
        );
        await Promise.all(imgCreates);
      }

      // Create notification if now low stock (and wasn't before)
      if (isLowStock && !wasLowStock) {
        await tx.notification.create({
          data: {
            userId: null,
            type: 'LOW_STOCK',
            message: `Low stock alert: ${product.name} (${newQuantity} remaining)`,
            isRead: false
          }
        });
      }

      return updatedProduct;
    });

    console.log('Inventory updated:', result.id);

    return res.status(200).json({
      success: true,
      message: 'Inventory updated successfully.',
      data: {
        productId: result.id,
        product: result,
        newStock: result.totalStock,
        quantity: result.totalStock,
        isLowStock: result.totalStock <= result.lowStockThreshold,
        lowStockThreshold: result.lowStockThreshold,
        lastUpdated: result.updatedAt
      }
    });
  } catch (error) {
    console.error('Update inventory error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating inventory.'
    });
  }
};

// Bulk update inventory (Admin only)
const bulkUpdateInventory = async (req, res) => {
  try {
    const { updates } = req.body;
    const adminId = req.user?.id;

    console.log('Bulk update inventory request');

    if (!Array.isArray(updates) || updates.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Updates array is required.'
      });
    }

    const results = [];
    const errors = [];

    for (const update of updates) {
      try {
        const { productId, quantity } = update;

        const product = await prisma.product.findUnique({
          where: { id: parseInt(productId) }
        });

        if (!product) {
          errors.push({ productId, error: 'Product not found' });
          continue;
        }

        const isLowStock = quantity <= product.lowStockThreshold;
        const wasLowStock = product.totalStock <= product.lowStockThreshold;

        // Update product and create log in transaction
        const updatedProduct = await prisma.$transaction(async (tx) => {
          const result = await tx.product.update({
            where: { id: parseInt(productId) },
            data: {
              totalStock: parseInt(quantity)
            }
          });

          // Create inventory log
          await tx.inventoryLog.create({
            data: {
              productId: parseInt(productId),
              action: 'ADJUST',
              quantity: parseInt(quantity) - product.totalStock,
              adminId: adminId || null,
              note: `Bulk update: set to ${quantity}`
            }
          });

          // Create notification if now low stock
          if (isLowStock && !wasLowStock) {
            await tx.notification.create({
              data: {
                userId: null,
                type: 'LOW_STOCK',
                message: `Low stock alert: ${product.name} (${quantity} remaining)`,
                isRead: false
              }
            });
          }

          return result;
        });

        results.push({
          productId: updatedProduct.id,
          quantity: updatedProduct.totalStock,
          isLowStock: updatedProduct.totalStock <= updatedProduct.lowStockThreshold
        });
      } catch (err) {
        errors.push({ productId: update.productId, error: err.message });
      }
    }

    console.log(`Bulk update completed: ${results.length} successful, ${errors.length} errors`);

    return res.status(200).json({
      success: true,
      message: 'Bulk inventory update completed.',
      data: {
        successful: results,
        errors,
        successCount: results.length,
        errorCount: errors.length
      }
    });
  } catch (error) {
    console.error('Bulk update inventory error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while bulk updating inventory.'
    });
  }
};

// Get inventory for a specific product
const getProductInventory = async (req, res) => {
  try {
    const { productId } = req.params;

    console.log('Get product inventory:', productId);

    const product = await prisma.product.findUnique({
      where: { id: parseInt(productId) },
      include: {
        images: {
          where: { isPrimary: true },
          take: 1
        },
        inventoryLogs: {
          take: 10,
          orderBy: {
            createdAt: 'desc'
          },
          include: {
            admin: {
              select: {
                id: true,
                name: true,
                email: true
              }
            }
          }
        }
      }
    });

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    const inventory = {
      productId: product.id,
      product: product,
      quantity: product.totalStock,
      isLowStock: product.totalStock <= product.lowStockThreshold,
      lowStockThreshold: product.lowStockThreshold,
      lastUpdated: product.updatedAt,
      recentLogs: product.inventoryLogs
    };

    return res.status(200).json({
      success: true,
      message: 'Product inventory retrieved successfully.',
      data: inventory
    });
  } catch (error) {
    console.error('Get product inventory error:', error);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching product inventory.'
    });
  }
};

module.exports = {
  getAllInventory,
  getLowStockProducts,
  updateInventory,
  bulkUpdateInventory,
  getProductInventory
};